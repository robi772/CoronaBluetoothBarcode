local globals = {}

globals.appId = "YOUR-CORONIUM-IP"
globals.apiKey = "YOUR-CORONIUM-KEY"

return globals